API Documentation
=================

Base URL: http://<host>:5000

Overlays
--------
POST /api/overlays
  Body (JSON): { type: "text"|"image", text?: "...", image_url?: "...", x?:int, y?:int, width?:int, height?:int }
  Response: { _id: "<id>" }

GET /api/overlays
  Returns list of overlays

GET /api/overlays/<id>
  Returns overlay object

PUT /api/overlays/<id>
  Body: fields to update

DELETE /api/overlays/<id>
  Deletes overlay

Stream control (starts ffmpeg on server to create HLS)
----------------------------------------------------
POST /api/stream/start
  Body: { rtsp_url: "...", name?: "streamname" }
  Response: { status: "started", hls_path: "/hls/<name>/index.m3u8" }

POST /api/stream/stop
  Body: { name: "streamname" }
  Response: { status: "stopped" }

HLS files served at /hls/<name>/index.m3u8 and segment files.
