User Documentation - How to use
===============================

1. Start backend and MongoDB (docker-compose recommended)
2. Ensure ffmpeg is installed on the backend host
3. Open the web UI at http://localhost:5000
4. Enter an RTSP URL (for example from rtsp.me or your camera). Choose a stream name.
5. Click 'Start Stream' — the backend will attempt to run ffmpeg and create an HLS playlist.
6. When started, the player will load the HLS playlist and play in the browser.
7. Click 'Add sample overlay' to create a text overlay. Use the saved overlays list to manage overlays (via API or future UI enhancements).

Notes on overlay positioning:
- The React UI uses draggable and resizable components and loads overlay positions from the server.
- For production use, you may want to implement saving overlay positions after the user moves/resizes the overlay (not implemented in sample).

