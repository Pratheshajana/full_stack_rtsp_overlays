Full Stack RTSP Overlays Player
=================================

What this provides
- Flask backend with CRUD API for overlays (MongoDB)
- Endpoint to start/stop FFmpeg conversion from RTSP -> HLS
- React frontend (sample) that plays HLS with overlays (draggable, resizable)
- Docker-compose to run MongoDB and backend
- Instructions and API docs

Important notes
- To convert RTSP to HLS the server uses ffmpeg. ffmpeg must be installed on the machine running the backend.
- Browsers cannot directly play RTSP. The backend converts RTSP to HLS and serves via /hls/<name>/index.m3u8
- Replace RTSP URL with a valid RTSP stream (e.g., use rtsp.me demo streams or your camera)

Quick start (local)
1. Ensure Docker and docker-compose are installed.
2. From the project root run:
   docker-compose up --build
3. Install ffmpeg on the host (so backend's ffmpeg command can run). On Debian/Ubuntu: sudo apt install ffmpeg
4. Open http://localhost:5000

Running without Docker (development)
- Backend:
  cd backend
  python -m venv venv
  source venv/bin/activate   # or venv\Scripts\activate on Windows
  pip install -r requirements.txt
  export MONGO_URI=mongodb://localhost:27017/overlaysdb
  python app.py
- Frontend:
  cd frontend
  npm install
  npm run build
  copy build contents into backend/frontend/build or run frontend dev server and configure proxy.

Files of interest:
- backend/app.py  (Flask backend, overlays API, stream start/stop, serves HLS and frontend)
- frontend/src/App.jsx  (React UI)
- docker-compose.yml  (run mongo + backend)
- README.md, API_DOCS.md, USER_DOCS.md

