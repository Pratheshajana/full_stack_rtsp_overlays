from flask import Flask, request, jsonify, send_from_directory
from flask_pymongo import PyMongo
from bson.objectid import ObjectId
from flask_cors import CORS
import os, subprocess, threading, time

app = Flask(__name__, static_folder="../frontend/build", static_url_path="/")
CORS(app)

# MongoDB config via env
app.config["MONGO_URI"] = os.environ.get("MONGO_URI", "mongodb://mongo:27017/overlaysdb")
mongo = PyMongo(app)
overlays_col = mongo.db.overlays

@app.route("/api/overlays", methods=["POST"])
def create_overlay():
    data = request.json
    res = overlays_col.insert_one(data)
    return jsonify({"_id": str(res.inserted_id)}), 201

@app.route("/api/overlays", methods=["GET"])
def list_overlays():
    docs = []
    for d in overlays_col.find():
        d["_id"] = str(d["_id"])
        docs.append(d)
    return jsonify(docs)

@app.route("/api/overlays/<id>", methods=["GET"])
def get_overlay(id):
    d = overlays_col.find_one({"_id": ObjectId(id)})
    if not d:
        return jsonify({"error":"not found"}), 404
    d["_id"] = str(d["_id"])
    return jsonify(d)

@app.route("/api/overlays/<id>", methods=["PUT"])
def update_overlay(id):
    data = request.json
    overlays_col.update_one({"_id": ObjectId(id)}, {"$set": data})
    return jsonify({"ok":True})

@app.route("/api/overlays/<id>", methods=["DELETE"])
def delete_overlay(id):
    overlays_col.delete_one({"_id": ObjectId(id)})
    return jsonify({"ok":True})

# Endpoint to start HLS conversion for a given RTSP url (starts background ffmpeg process)
# NOTE: ffmpeg must be installed on the host. This implementation creates a simple HLS stream
# in /tmp/hls/<name> and serves via /hls/<name>/index.m3u8
HLS_BASE = "/tmp/hls_streams"
os.makedirs(HLS_BASE, exist_ok=True)
ffmpeg_processes = {}

def start_ffmpeg(rtsp_url, name):
    outdir = os.path.join(HLS_BASE, name)
    os.makedirs(outdir, exist_ok=True)
    # remove old files
    for f in os.listdir(outdir):
        try:
            os.remove(os.path.join(outdir,f))
        except:
            pass
    # ffmpeg command to generate HLS
    cmd = [
        "ffmpeg", "-y",
        "-i", rtsp_url,
        "-c:v", "copy",
        "-c:a", "aac",
        "-f", "hls",
        "-hls_time", "2",
        "-hls_list_size", "6",
        "-hls_flags", "delete_segments",
        os.path.join(outdir, "index.m3u8")
    ]
    # start subprocess
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ffmpeg_processes[name] = {"proc": proc, "rtsp": rtsp_url, "outdir": outdir}
    return proc.pid

@app.route("/api/stream/start", methods=["POST"])
def stream_start():
    data = request.json
    rtsp = data.get("rtsp_url")
    name = data.get("name", "default")
    if not rtsp:
        return jsonify({"error":"rtsp_url required"}), 400
    if name in ffmpeg_processes:
        return jsonify({"status":"already_running","name":name})
    try:
        pid = start_ffmpeg(rtsp, name)
        return jsonify({"status":"started","name":name,"pid":pid,"hls_path":f"/hls/{name}/index.m3u8"})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/api/stream/stop", methods=["POST"])
def stream_stop():
    data = request.json
    name = data.get("name","default")
    info = ffmpeg_processes.get(name)
    if not info:
        return jsonify({"status":"not_running"})
    try:
        info["proc"].terminate()
    except:
        pass
    ffmpeg_processes.pop(name, None)
    return jsonify({"status":"stopped","name":name})

# Serve HLS files
@app.route("/hls/<name>/<path:filename>")
def hls_files(name, filename):
    outdir = os.path.join(HLS_BASE, name)
    if not os.path.isdir(outdir):
        return jsonify({"error":"stream not found"}), 404
    return send_from_directory(outdir, filename)

# Serve frontend
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path):
    # if path exists in build, serve it
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, "index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=True)
