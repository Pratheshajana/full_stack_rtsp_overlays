import React, {useState, useEffect, useRef} from "react";
import axios from "axios";
import Hls from "hls.js";
import Draggable from "react-draggable";
import { ResizableBox } from "react-resizable";
import "./styles.css";

function Player({hlsUrl, overlays}) {
  const videoRef = useRef();
  useEffect(() => {
    const v = videoRef.current;
    if (Hls.isSupported()) {
      const hls = new Hls();
      hls.loadSource(hlsUrl);
      hls.attachMedia(v);
      return () => { hls.destroy(); };
    } else {
      v.src = hlsUrl;
    }
  }, [hlsUrl]);
  return (
    <div className="player-wrap">
      <video ref={videoRef} controls autoPlay style={{width:"100%", height:"auto"}} />
      {overlays.map(o => (
        <Draggable key={o._id} defaultPosition={{x:o.x||10,y:o.y||10}}>
          <div className="overlay" style={{position:"absolute", left:0, top:0, zIndex:10}}>
            <ResizableBox width={o.width||200} height={o.height||60} minConstraints={[50,20]}>
              <div style={{padding:8, background:"rgba(255,255,255,0.6)", borderRadius:8}}>
                {o.type==="text" ? <div>{o.text}</div> : <img src={o.image_url} style={{width:"100%",height:"100%",objectFit:"contain"}}/>}
              </div>
            </ResizableBox>
          </div>
        </Draggable>
      ))}
    </div>
  );
}

export default function App(){
  const [rtsp, setRtsp] = useState("");
  const [hlsUrl, setHlsUrl] = useState("");
  const [overlays, setOverlays] = useState([]);
  const [name, setName] = useState("default");
  useEffect(()=>{ fetchOverlays(); },[]);
  async function fetchOverlays(){
    const res = await axios.get("/api/overlays");
    setOverlays(res.data);
  }
  async function startStream(){
    try{
      const res = await axios.post("/api/stream/start",{rtsp_url:rtsp,name});
      if(res.data.hls_path){
        setHlsUrl(res.data.hls_path);
      } else {
        alert(JSON.stringify(res.data));
      }
    }catch(e){ alert("Failed to start stream: "+e); }
  }
  async function createSampleText(){
    const res = await axios.post("/api/overlays",{type:"text",text:"Hello Overlay",x:20,y:20,width:220,height:60});
    fetchOverlays();
  }
  return (
    <div className="app">
      <header className="header">
        <h1>RTSP Overlays Player</h1>
      </header>
      <main>
        <section className="controls">
          <input placeholder="RTSP URL" value={rtsp} onChange={e=>setRtsp(e.target.value)} />
          <input placeholder="Stream name (default)" value={name} onChange={e=>setName(e.target.value)} />
          <button onClick={startStream}>Start Stream (HLS)</button>
          <button onClick={createSampleText}>Add sample overlay</button>
        </section>
        <section className="player-section">
          {hlsUrl ? <Player hlsUrl={hlsUrl} overlays={overlays} /> : <div className="placeholder">No stream started. Enter RTSP and click Start Stream.</div>}
        </section>
        <section className="overlay-list">
          <h2>Saved Overlays</h2>
          <ul>
            {overlays.map(o=>(
              <li key={o._id}>
                {o.type} - {o._id}
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
